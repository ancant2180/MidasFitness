package applicationModel;

public class Food {
	/**
	 * Food is a java class that identifies the integral parts to a food item.  Every Food has a name, and it's macronutrients
	 * This class was made with the intention of quickly pulling information for certain food items, as characterized by the
	 * multiple getter and setter functions.
	 *
	 * @author Aaron Nicholas Cantu dth885
	 * @author Jasmyn Charles vhh036
	 * @author Bryce Hinkley mzl963
	 * UTSA CS 3443 - Final Project
	 * Spring 2021
	 *
	 */
	private double carbs;
	private double protein;
	private double fat;
	private double calories;
	private double sugar;
	private String foodName;
	

	
	public Food() {

	}
		

    /**
     * setCalories receives a double value for the total calories a food has, then sets the variable calories to that received value
     * 
     * @param calories
     */
	
	public void setCalories(double calories) 
	{
		this.calories = calories;
	}	
	
	 /**
     * setCarbs receives a double value for the total carbs a food has, then sets the variable carbs to that recieved value
     * 
     * @param carbs
     */
	public void setCarbs(double carbs) {
		this.carbs = carbs;
	}
	
	 /**
     * setFat receives a double value for the total fat a food has, then sets the variable fat to that recieved value
     * 
     * @param fat
     */
	public void setFat(double fat) {
		this.fat = fat;
	}
	
	 /**
     * setSugar receives a double value for the amount of sugar a food has, then sets the variable sugar to that recieved value
     * 
     * @param sugar
     */
	public void setSugar(double sugar) {
		this.sugar = sugar;
	}
	

	 /**
     * setFoodName receives a String for the food name, then sets the variable name to that recieved value
     * 
     * @param foodName
     */
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	
	/**
     * setProtein receives a double value for the amount of protein a food has, then sets the variable protein to that recieved value
     * 
     * @param protein
     */
	public void setProtein(double protein) {
		this.protein = protein;
	}
	
	//getters
	 /**
     * getFoodName is a method that returns the food name
     * 
     * @return
     */
	public String getFoodName()
	{
		return this.foodName;
	}
	
	/**
     * getCalories is a method that returns the number of calories a food has
     * 
     * @return
     */
	public double getCalories() {
		return this.calories;
	}
	
	/**
     * getProtein is a method that returns the amount of protein a food has
     * 
     * @return
     */
	public double getProtein() {
		return this.protein;
	}
	
	 /**
     * getCarbs is a method that returns the amount of carbs a food has
     * @return
     */
	public double getCarbs() {
		return this.carbs;
	}
	
	 /**
     * getSugar is a method that returns the amount of sugar a food has
     * 
     * @return
     */
	public double getSugar() {
		return this.sugar;
	}
	
	/**
     *  getFat is a method that returns the amount of fat a food has
     * 
     * @return
     */
	public double getFat() {
		return this.fat;
	}

}
