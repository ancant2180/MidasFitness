package applicationModel;
import java.io.*;
import java.util.Calendar;
/**
 * FileHandlingOverview is a class designed to be the master file to the FileHandlingFood and FileHandlingWorkouts files. It contains several methods used
 * throughout the program to work with these files
 *.
 *
 * @author Aaron Nicholas Cantu dth885
 * @author Jasmyn Charles vhh036
 * @author Bryce Hinkley mzl963
 * UTSA CS 3443 - Final Project
 * Spring 2021
 *
 */

public class FileHandlingOverview {
    //Constructor (NEW)
    public FileHandlingOverview(){ }


    /**
     * The addWorkout method takes the name of the workout passed from the listView and the amount of minutes performed. Then adds
     * this data to the dailyActivityW.csv file
     * @throws IOException
     *  
     */
    public void addWorkout(String wkoutName,double minutes) throws IOException {
        boolean needsChangeDate = !dateIsCorrect("dailyActivityW.csv");
        FileWriter printer = new FileWriter("dailyActivityW.csv", dateIsCorrect("dailyActivityW.csv"));
        BufferedWriter bw = new BufferedWriter(printer);

        FileHandlingWorkouts workoutsCSV = new FileHandlingWorkouts();
        System.out.println("Checkpoint 1 addWorkout to Overview...");



        String workout ="";
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(
                    "exercises.csv"));
            String line = reader.readLine();
            while (line != null) {
                if(line.contains(wkoutName))
                    workout = line;
                // read next line
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }


        bw.write("\n"+workoutsCSV.findWorkoutName(wkoutName)+","+((workoutsCSV.findWorkoutCal(wkoutName)*1)+""));


        bw.close();
    }

    /**
     * The addFood method takes the name of the food passed from the listView and the amount of servings. Then adds
     * this data to the dailyActivityF.csv file
     * @throws IOException
     */
    public void addFood(String foodName,int servings) throws IOException {
        boolean needsChangeDate = !dateIsCorrect("dailyActivityF.csv");
        FileWriter printer = new FileWriter("dailyActivityF.csv", dateIsCorrect("dailyActivityF.csv"));
        BufferedWriter bw = new BufferedWriter(printer);

        FileHandlingFood foodCSV = new FileHandlingFood();
        System.out.println("Checkpoint 1 addFood to Overview...");

        String foodline ="";
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(
                    "food.csv"));
            String line = reader.readLine();
            while (line != null) {
                if(line.contains(foodName))
                    foodline = line;
                // read next line
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Checkpoint 2 addFood to Overview...");
        if(needsChangeDate)
            bw.write(""+Calendar.getInstance().get(Calendar.DAY_OF_YEAR));
        bw.write("\n"+(foodCSV.findFoodName(foodName)));
        bw.write(","+(foodCSV.findFoodCal(foodName)*(servings+0.0)));
        bw.write(","+(foodCSV.findFoodPro(foodName)*(servings+0.0)));
        bw.write(","+(foodCSV.findFoodCarbs(foodName)*(servings+0.0)));
        bw.write(","+(foodCSV.findFoodSug(foodName)*(servings+0.0)));
        bw.write(","+(foodCSV.findFoodFat(foodName)*(servings+0.0)));

        System.out.println("Checkpoint 3 addFood to Overview...");

        bw.close();
    }

    /**
     * The dateIsCorrect method takes the name of the file passed to check for a date in. Then returns
     * a boolean value to determine if the file contains the correct date by using the day of the year
     * instance in Calendar
     * @throws IOException
     * @return boolean 
     */
    private boolean dateIsCorrect(String fileName) throws IOException {

        int date = Calendar.getInstance().get(Calendar.DAY_OF_YEAR);

        String content = "";
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(fileName));
            content = reader.readLine();
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(date==Integer.parseInt(content)){
            return true;
        }else{
            return false;
        }

    }

    /**
     * The readFoodsFromCSV reads all current food within the dailyActivityF.csv file and returns them
     * @throws IOException
     * @return content Contents of food csv file (String)
     */
    public String readFoodsFromCSV(){
        String content = "";
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(
                    "dailyActivityF.csv"));
            String line = reader.readLine();
            line = reader.readLine();
            while (line != null) {
                content = content+line+"\n";
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content;
    }

    /**
     * The readWorkoutsFromCSV reads all current workouts within the dailyActivityW.csv file and returns them
     * @throws IOException
     * @return content Contents of workout csv file (String)
     */
    public String readWorkoutsFromCSV(){
        String content = "";
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(
                    "dailyActivityW.csv"));
            String line = reader.readLine();
            line = reader.readLine();
            while (line != null) {
                content = content+line+"\n";
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //System.out.println(content);
        return content;
    }

    /**
     * The calculateCaloriesWorkout reads all current workouts within the dailyActivityW.csv file and returns the
     * value of added needed calories
     * @throws IOException
     * @return count Total calories of workout (double)
     */
    public double calculateCaloriesWorkout(){
        double count = 0.0;

        String content = "";
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(
                    "dailyActivityW.csv"));
            String line = reader.readLine();
            line = reader.readLine();
            while (line != null) {
                content = line;
                String[] tokens = content.split(",");
                count =+ Double.parseDouble(tokens[1]);

                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(count);

        return count;
    }
    
    /**
     * The calculateNutrientFoods reads all current foods within the dailyActivityF.csv file and returns the
     * value of total deducted needed calories
     * @throws IOException
     * @param type Index of food type
     * @return double Amount of nutrient needed in day
     */
    public double calculateNutrientFoods(int type){
        double count = 0.0;

        String content = "";
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(
                    "dailyActivityF.csv"));
            String line = reader.readLine();
            line = reader.readLine();
            while (line != null) {
                content = line;
                String[] tokens = content.split(",");
                count =+ Double.parseDouble(tokens[type]);
                //System.out.println(line);
                // read next line
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(count);

        return count;
    }

    /**
     * The calculateDailyExpenditure uses the calculateCaloriesWorkout and calculateNutrientFoods functions to calculate the total expenditure
     * of food intake and caloric burning
     * @throws IOException
     * @return calNeeds Total caloric needs for the day
     */
    public double calculateDailyExpenditure(){
        double calNeeds = calculateCaloriesWorkout()-calculateNutrientFoods(1);
        System.out.println(calNeeds);
        return calNeeds;
    }

}
