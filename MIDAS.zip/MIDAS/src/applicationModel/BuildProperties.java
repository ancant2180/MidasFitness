package applicationModel;
import java.io.*;
/**
 * BuildProperties is a class designed to build the properties files used essentially as settings upon user reentry of the program.
 * It is capable of building two different files; prop1.properties and prop2.properties
 * They recieve data from the events within the Controller and are parsed data from the FileHandlers
 *
 * @author Aaron Nicholas Cantu dth885
 * @author Jasmyn Charles vhh036
 * @author Bryce Hinkley mzl963
 * UTSA CS 3443 - Final Project
 * Spring 2021
 *
 */


public class BuildProperties {

    public BuildProperties(){}

    /**
     * This is the function to write to the properties file prop1. It is for the user myProfile.fxml scene. It receives the name, height, weight,
     * target weight, sex, lifestyle place, age, isWeightLifting boolean, the change of weight placement, and the nutrient goals of the user and
     * writes these to the prop1 file
     * 
     * @param name 
     * @param height  
     * @param weight 
     * @param targetWeight 
     * @param sex 
     * @param lifestyle 
     * @param age 
     * @param isWeightLifting 
     * @param change 
     * @param goals 
     */
    public void writeToProp1(String name, String height, String weight, String targetWeight, String sex, int lifestyle, int age, boolean isWeightLifting, int change, String goals) throws IOException {

        File overWrite = new File("applicationView.prop1.properties");
        FileWriter printer = new FileWriter("applicationView.prop1.properties");

        String changeS = "";
        String isWeightLiftingS = null;
        if(isWeightLifting){
            isWeightLiftingS = "Yes";}
        else{
            isWeightLiftingS = "No";}
        String ageS = age+"";
        String lifestyleS = "";

        switch(change)
        {
            case 0:
                changeS=".25 kg";
                break;
            case 1:
                changeS=".50 kg";
                break;
            case 2:
                changeS=".75 kg";
                break;
            case 3:
                changeS="1 kg";
                break;
            default:
                System.out.println("Error: Lifestyle set from save to user not working. Please investigate.");
        }


        switch(lifestyle)
        {
            case 0:
                lifestyleS="Sedentary";
                break;
            case 1:
                lifestyleS="Lightly Active";
                break;
            case 2:
                lifestyleS="Moderately Active";
                break;
            case 3:
                lifestyleS="Very Active";
                break;
            case 4:
                lifestyleS="Super Active";
                break;
            default:
                System.out.println("Error: Lifestyle set from save to user not working. Please investigate.");
        }


        BufferedWriter bw = new BufferedWriter(printer);
        bw.write("a2 = Change Profile\n");
        bw.write("name = "+name);
        bw.write("\nheight = "+height);
        bw.write("\nweight = "+weight);
        bw.write("\ntWeight = "+targetWeight);
        bw.write("\nlifestyle = "+lifestyleS);
        if(sex.equals("M"))
            bw.write("\nsex = Male");
        if(sex.equals("F"))
            bw.write("\nsex = Female");
        bw.write("\ndoYouLiftBro = "+isWeightLiftingS);
        bw.write("\nchange = "+changeS);
        bw.write("\ndailyGoals = "+goals);
        bw.newLine();
        bw.close();


    }

    /**
     * This is the function to write to the properties file prop2. It is for the user view.fxml scene. It recieves the name, weight,
     * target weight, and the nutrient goals of the user and writes these to the prop2 file to be used as variables in .fxml
     * 
     * @param name 
     * @param weight 
     * @param weightTarget 
     * @param goals 
     */
    public void writeToProp2(String name,String weight,String weightTarget,String goals) throws IOException {
        File overWrite = new File("applicationView.prop2.properties");
        FileWriter printer = new FileWriter("applicationView.prop2.properties");

        BufferedWriter bw = new BufferedWriter(printer);
        bw.write("name = Welcome "+name);
        bw.write("\nweight = Your current weight: "+ weight);
        bw.write("\nweightT = Target weight: "+ weightTarget);
        bw.write("\ndailyGoals = "+ goals);
        bw.newLine();
        bw.close();

    }

}


