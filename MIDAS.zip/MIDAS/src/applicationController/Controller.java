package applicationController;
import java.net.URL;
import java.util.ResourceBundle;

import applicationModel.FileHandlingFood;
import applicationModel.FileHandlingUser;
import applicationModel.FileHandlingWorkouts;
import applicationModel.User;
import applicationModel.BuildProperties;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.*;
import applicationModel.*;
/**
 * Controller is a java class that handles the majority of scene and stage changes. It contains the FXML controls such as the buttons, textfields, labels, comboboxes,
 * and listView objects. Additionally, controller contains refresh functions and property building functions. This was due to difficulty in passing objects between
 * the scenes. The controller has a lot of interaction with all of the FileHandling classes such as FileHandlingUser and FileHandlingFood. It also works with the 
 * User class and the buildProperties class to handle the temporary User data and property file building respectively.
 *
 * @author Aaron Nicholas Cantu dth885
 * @author Jasmyn Charles vhh036
 * @author Bryce Hinkley mzl963
 * UTSA CS 3443 - Final Project
 * Spring 2021
 *
 */
public class Controller implements Initializable {
    FileHandlingUser userCSV = new FileHandlingUser();
    FileHandlingWorkouts fuc = new FileHandlingWorkouts();
    User userData = new User();
    BuildProperties userSettings = new BuildProperties();
    FileHandlingFood userToCSVFoodFile = new FileHandlingFood();

    //String weight = Double.toString(userData.getWeight());
    @FXML
    private Button toMyProfile,backToSample,toAddMeal,toAddWorkout, saveMyProfile, addFoodToAct, addWorkoutButton,btnOpenNewWindow;
    @FXML
    private TextField currentWeight,targetWeight,height,nameInput,servings,minutesP,createFoodName,createFoodCal,createFoodPro,createFoodCarb,createFoodSug,createFoodFat;
    @FXML
    private ComboBox <String> userSex, lifestyleBox, weightliftingBox, weightChangePerWeek;
    @FXML
    private Label a2, foodsInOverview,workoutLabel,welcomeName,labelWeight,labelTargetWeight,nutGoals,myProfileGoals,recommendations;
    @FXML
    private ListView foodList, workoutList;
    FileHandlingFood foodsToChoose = new FileHandlingFood();

    ResourceBundle resources = ResourceBundle.getBundle("applicationView.prop1");
    
    //constructor
    public Controller() throws IOException {
    }

    /**
     * handleButtonAction. Receives the FXML ActionEvent of #handleButtonAction from different buttons. It takes the source
     * of buttons to direct them to the new scene with a new stage.
     */
    @FXML
    private void handleButtonAction (ActionEvent event) throws Exception {
        Stage stage = null;
        Parent root = null;

            if(event.getSource()==toAddWorkout){
                stage = (Stage) toAddWorkout.getScene().getWindow();
                root = FXMLLoader.load(getClass().getResource("/applicationView/addWorkout.fxml"));
        }
            if(event.getSource()==toMyProfile){
                stage = (Stage) toMyProfile.getScene().getWindow();
                ResourceBundle.clearCache();
                ResourceBundle resources = ResourceBundle.getBundle("applicationView.prop1");
                root = FXMLLoader.load(getClass().getResource("/applicationView/myProfile.fxml"),resources);
               

        } if(event.getSource()==toAddMeal){
            stage = (Stage) toAddMeal.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("/applicationView/addMeal.fxml"));



        } if(event.getSource()==backToSample){
            stage = (Stage) backToSample.getScene().getWindow();
            ResourceBundle.clearCache();
            ResourceBundle resources = ResourceBundle.getBundle("applicationView.prop2");
            root = FXMLLoader.load(getClass().getResource("/applicationView/view.fxml"),resources);
        }
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    /**
     * handleCreateMealWindow. Receives the FXML ActionEvent of #handleCreateMealWindow from the button btnOpenNewWindow.
     * It creates a new window without closing the previous one to display a scene populated by textFields to receive the info typed in them.
     * This pairs with handleFoodCreationEvent
     */
    public void handleCreateMealWindow(ActionEvent event){

        Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource("/applicationView/createFood.fxml"));
            Stage stage = new Stage();
            stage.setTitle("Food Creation");
            stage.setScene(new Scene(root, 600, 450));
            stage.show();
            // Hide this current window (if this is what you want)
            //((Node)(event.getSource())).getScene().getWindow().hide();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * handleSaveProfile. Receives the FXML ActionEvent of #handleSaveProfile from the button saveMyProfile.
     * It uses multiple try and catches to acquire data from the input fields but if they return null that is handled by the .csv file for the user
     * At the end of the function the setToCSV function is called to save and overwrite the information to the user .csv file
     * It also calls two separate properties files prop1 and prop2 to build the properties files with overwritten information
     */
    @FXML
    private void handleSaveProfile (ActionEvent event) throws Exception {
        if(event.getSource()==saveMyProfile){

            try{
                userData.setWeight(currentWeight.getText());
            }catch (NullPointerException e){
                userData.setWeight(userCSV.readWeight()+"");
            }
            try{
                userData.setWeightTarget(targetWeight.getText());
            }catch (NullPointerException e){
                userData.setWeightTarget(userCSV.readWeightTarget()+"");
            }
                try {
                    if (userSex.getValue().equals("Male") )
                        userData.setSex('M');
                    if (userSex.getValue().equals("Female") )
                        userData.setSex('F');
                } catch(NullPointerException e){
                    if(userCSV.readSex() == 'M')
                        userData.setSex('M');
                    if(userCSV.readSex()=='F')
                        userData.setSex('F');
                }
            if(height.equals("")){userData.setHeight("0");}else{userData.setHeight(height.getText());}
            if(nameInput.equals(" ")){userData.setName(" ");}else{userData.setName(nameInput.getText());}


            try {
                String str = lifestyleBox.getValue();
                switch (str) {
                    case "Sedentary":
                        userData.setLifestyle(0);
                        break;
                    case "Lightly active":
                        userData.setLifestyle(1);
                        break;
                    case "Moderately active":
                        userData.setLifestyle(2);
                        break;
                    case "Very active":
                        userData.setLifestyle(3);
                        break;
                    case "Super active":
                        userData.setLifestyle(4);
                        break;
                    default:
                        System.out.println("Error: Lifestyle set from save to user not working. Please investigate.");
                }
            } catch(NullPointerException e){
                userData.setLifestyle(userCSV.readLifestyle());
            }
            try {
                String str2 = weightliftingBox.getValue();
                switch (str2) {
                    case "Yes":
                        userData.setWeightlifting('Y');
                        System.out.println("Yes weightlifte");
                        break;
                    case "No":
                        userData.setWeightlifting('N');
                        System.out.println("No weightlifte");
                        break;
                    default:
                        System.out.println("Error: Weightlifting from save to user not working. Please investigate.");
                }
            } catch (NullPointerException e){
                if(userCSV.readIsWeightlifting()){
                userData.setWeightlifting('N');}else{
                    userData.setWeightlifting('Y');
                }
            }
            try {
                String str3 = weightChangePerWeek.getValue();
                switch (str3) {
                    case ".25 kg":
                        userData.setWeightChangePerWeek(0);
                        userData.setChange(.25);
                        break;
                    case ".5 kg":
                        userData.setWeightChangePerWeek(1);
                        userData.setChange(.50);
                        break;
                    case ".75 kg":
                        userData.setWeightChangePerWeek(2);
                        userData.setChange(.75);
                        break;
                    case "1 kg":
                        userData.setWeightChangePerWeek(3);
                        userData.setChange(1.0);
                        break;
                    default:
                        System.out.println("Error: Weight change set from save to user not working. Please investigate.");
                }
            } catch (NullPointerException e){
                userData.setWeightChangePerWeek(userCSV.readChange());
                userData.setWeightChangePerWeekDouble(userCSV.readChangeDouble());
            }
            userData.setToCSV();
            System.out.print("\nUser Name: "+userData.getName()+"\nUser Sex: "+userData.getSex()+"\nUser Height: "+userData.getHeight());
            System.out.print(" cm.\nCurrent weight: "+userData.getWeight()+" kgs. User target weight: "+userData.getWeightTarget()+" kgs.");
            userSettings.writeToProp1(userData.getName(),Double.toString(userData.getHeight()),Double.toString(userData.getWeight()),Double.toString(userData.getWeightTarget()), Character.toString(userData.getSex()),userCSV.readLifestyle(),userCSV.readAge(),userCSV.readIsWeightlifting(),userCSV.readChange(),userCSV.readDailyGoalsLine());
            userSettings.writeToProp2(userCSV.readName(),userCSV.readWeight()+"",userCSV.readWeightTarget()+"",userCSV.readDailyGoalsLine());
        }
    }

    /**
     * refreshSampleAction. Receives the FXML ActionEvent of #refreshSampleAction from the refresh button located in the view.fxml file.
     * It reloads the information from .csv files to the view.fxml so display updated information such as new foods being added
     */
    @FXML
    private void refreshSampleAction (ActionEvent event) throws Exception {
        FileHandlingOverview overview = new FileHandlingOverview();
        //foodsToChoose.createDefault();
        foodsInOverview.setText("Foods\n"+overview.readFoodsFromCSV());
        //fuc.createDefaultExercises();
        workoutLabel.setText(overview.readWorkoutsFromCSV());
        welcomeName.setText("Welcome "+userCSV.readName());
        labelWeight.setText("Your weight is "+userCSV.readWeight());
        labelTargetWeight.setText("Your desired weight is "+userCSV.readWeightTarget());
        nutGoals.setText("Calories: "+(userCSV.readDailyGoalsCal()+(overview.calculateDailyExpenditure()))+" Protein: "+(userCSV.readDailyGoalsPro()-overview.calculateNutrientFoods(2)+"")+" Carbs: "+(userCSV.readDailyGoalsCarbs()-overview.calculateNutrientFoods(3)+" Fat: "+(userCSV.readDailyGoalsFats()-overview.calculateNutrientFoods(5)+"")));
        overview.calculateDailyExpenditure();

    }
    
    /**
     * refreshMyProfileAction. Receives the FXML ActionEvent of #refreshMyProfileAction from the refresh button located in the myProfile.fxml file.
     * It reloads the information from .csv files to the view.fxml so display updated information such as new updates to the daily needs
     */
    @FXML
    private void refreshMyProfileAction (ActionEvent event) throws Exception {
        nameInput.setText(userCSV.readName());
        height.setText(Double.toString(userCSV.readHeight()));
        currentWeight.setText(Double.toString(userCSV.readWeight()));
        targetWeight.setText(Double.toString(userCSV.readWeightTarget()));
        if((userCSV.readSex())=='M'){
            userSex.getSelectionModel().select("Male");}
        if(userCSV.readSex()=='F'){
            userSex.getSelectionModel().select("Female");}
        if(userCSV.readIsWeightlifting()){
            weightliftingBox.getSelectionModel().select(1);}else{
            weightliftingBox.getSelectionModel().select(0);}
        lifestyleBox.getSelectionModel().select(userCSV.readLifestyle());
        weightChangePerWeek.getSelectionModel().select(userCSV.readChange());
        //System.out.print("\n\n"+userCSV.readSex());
        myProfileGoals.setText(userCSV.readDailyGoalsLine());
    }


    /**
     * handleButtonFood. Receives the FXML ActionEvent of #handleButtonFood from the refresh button located in the addMeal.fxml file.
     * It adds the log of how many servings of a meal or food was eaten, then added to the dailyActivityF.csv
     */
    @FXML
    private void handleButtonFood(ActionEvent event) throws Exception{
        FileHandlingOverview fileOver = new FileHandlingOverview();
        //System.out.println(servings.getText() + " servings of "+foodList.getSelectionModel().getSelectedItem());

        String name = (String) foodList.getSelectionModel().getSelectedItem();
        System.out.println(name);
        try{
            System.out.println(servings.getText() + " servings of "+foodList.getSelectionModel().getSelectedItem());
            fileOver.addFood(name,Integer.parseInt(servings.getText()));
        }catch (NullPointerException e){
            System.out.println("Error with food addition. Please review your command.");
        }

    }
  
    /**
     * handleButtonWorkouts. Receives the FXML ActionEvent of #handleButtonWorkouts from the Add Workout button located in the addWorkout.fxml file.
     * It adds the log of how many servings of a meal or food was eaten, then added to the dailyActivityW.csv
     */
    @FXML
    private void handleButtonWorkouts(ActionEvent event) throws Exception{
        FileHandlingOverview fileOver = new FileHandlingOverview();
        //System.out.println(minutesP.getText()+" minutes of "+workoutList.getSelectionModel().getSelectedItem());

        String name = (String) workoutList.getSelectionModel().getSelectedItem();
        System.out.println(name);
        try{
            System.out.println(minutesP.getText() + " minutes of "+workoutList.getSelectionModel().getSelectedItem());
            fileOver.addWorkout(name,Double.parseDouble(minutesP.getText()));
        }catch (NullPointerException e){
            System.out.println("Error with workout addition. Please review your command.");
        }

    }
    /**
     * refreshWorkout. Receives the FXML ActionEvent of #refreshWorkout from the Refresh button located in the addWorkout.fxml file.
     * It loads an arrayList of available workouts to chose from within a listView
     */
    @FXML
    private void refreshWorkout(ActionEvent event) throws Exception{
        ListView<String> list = new ListView<String>();
        ObservableList<String> data = FXCollections.observableArrayList(fuc.assembleArray());

        workoutList.setItems(data);

    }
    
    /**
     * handleFoodCreationEvent. Receives the FXML ActionEvent of #handleFoodCreationEvent from the Create button located in the createFood.fxml file.
     * Receives the information from the text fields and saves them to the .csv so they may be immediately used
     * Creating a food also closes the window of the program.
     */
    @FXML
    private void handleMealRefresh(ActionEvent event) throws Exception{
        ListView<String> list = new ListView<String>();
        ObservableList<String> data = FXCollections.observableArrayList(userToCSVFoodFile.assembleArray());

        foodList.setItems(data);

    }

    /**
     * handleFoodCreationEvent. Receives the FXML ActionEvent of #handleFoodCreationEvent from the Create button located in the createFood.fxml file.
     * Receives the information from the text fields and saves them to the .csv so they may be immediately used
     * Creating a food also closes the window of the program.
     */

    @FXML
    private void handleFoodCreationEvent(ActionEvent event) throws Exception{
        String name;
        double cal,pro,carb,sug,fat;

        try {
            name = createFoodName.getText();
        } catch (NullPointerException e){
            name = "Default Food";
        }

        try {
            cal = Double.parseDouble(createFoodCal.getText());
        } catch (NullPointerException e){
            cal = 0;
        }

        try {
            carb = Double.parseDouble(createFoodCarb.getText());
        } catch (NullPointerException e){
            carb = 0;
        }

        try {
            pro = Double.parseDouble(createFoodPro.getText());
        } catch (NullPointerException e){
            pro = 0;
        }

        try {
            fat = Double.parseDouble(createFoodFat.getText());
        } catch (NullPointerException e){
            fat = 0;
        }

        try {
            sug = Double.parseDouble(createFoodSug.getText());
        } catch (NullPointerException e){
            sug = 0;
        }

        userToCSVFoodFile.writeToCSV(name,cal,pro,carb,fat,sug);
        ((Node)(event.getSource())).getScene().getWindow().hide();

    }



    @FXML
    private void doTheHelp(){


    }


    /**
     * initialize. Override of the class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }



}
